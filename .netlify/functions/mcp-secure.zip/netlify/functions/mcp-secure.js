var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mcp_secure_exports = {};
__export(mcp_secure_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(mcp_secure_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "http://localhost:5173,https://your-domain.com").split(",");
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error("Missing required Supabase environment variables");
}
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseServiceKey);
const rateLimitStore = /* @__PURE__ */ new Map();
function checkRateLimit(ip, windowMs = 6e4, maxRequests = 100) {
  const now = Date.now();
  const windowStart = now - windowMs;
  if (!rateLimitStore.has(ip)) {
    rateLimitStore.set(ip, []);
  }
  const requests = rateLimitStore.get(ip);
  const validRequests = requests.filter((time) => time > windowStart);
  if (validRequests.length >= maxRequests) {
    return false;
  }
  validRequests.push(now);
  rateLimitStore.set(ip, validRequests);
  return true;
}
const toolSchemas = {
  get_safety_reviews: {
    required: ["city", "country"],
    types: { city: "string", country: "string" }
  },
  get_user_profile: {
    required: ["user_id"],
    types: { user_id: "string" }
  },
  get_destination_stats: {
    required: ["city", "country"],
    types: { city: "string", country: "string" }
  },
  search_destinations: {
    required: ["query"],
    types: { query: "string" }
  },
  get_recent_reviews: {
    required: [],
    types: { limit: "number" }
  }
};
function validateInput(tool, args) {
  const schema = toolSchemas[tool];
  if (!schema) {
    throw new Error(`Unknown tool: ${tool}`);
  }
  for (const field of schema.required) {
    if (!(field in args)) {
      throw new Error(`Missing required field: ${field}`);
    }
  }
  const sanitized = {};
  for (const [key, value] of Object.entries(args)) {
    if (key in schema.types) {
      const expectedType = schema.types[key];
      if (expectedType === "string") {
        if (typeof value !== "string") {
          throw new Error(`Field ${key} must be a string`);
        }
        sanitized[key] = value.replace(/[<>\"']/g, "").trim().substring(0, 100);
      } else if (expectedType === "number") {
        const num = Number(value);
        if (isNaN(num) || num < 0 || num > 1e3) {
          throw new Error(`Field ${key} must be a valid positive number under 1000`);
        }
        sanitized[key] = num;
      }
    }
  }
  return sanitized;
}
async function authenticateRequest(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new Error("Missing or invalid authorization header");
  }
  const token = authHeader.replace("Bearer ", "");
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    throw new Error("Invalid or expired token");
  }
  if (!user.email_confirmed_at) {
    throw new Error("Email not confirmed");
  }
  return user;
}
function checkOrigin(origin) {
  if (!origin) return false;
  return allowedOrigins.includes(origin) || allowedOrigins.includes("*");
}
async function handler(event, context) {
  const origin = event.headers.origin || event.headers.Origin;
  const isAllowedOrigin = checkOrigin(origin);
  const headers = {
    "Access-Control-Allow-Origin": isAllowedOrigin ? origin : allowedOrigins[0],
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const clientIP = event.headers["client-ip"] || event.headers["x-forwarded-for"]?.split(",")[0] || event.requestContext?.identity?.sourceIp || "unknown";
  if (!checkRateLimit(clientIP, 6e4, 30)) {
    return {
      statusCode: 429,
      headers,
      body: JSON.stringify({
        error: "Rate limit exceeded",
        message: "Too many requests. Please try again later.",
        retryAfter: 60
      })
    };
  }
  try {
    let requestBody;
    try {
      requestBody = JSON.parse(event.body || "{}");
    } catch (parseError) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Invalid JSON in request body" })
      };
    }
    const user = await authenticateRequest(event);
    const { tool, arguments: args } = requestBody;
    if (!tool) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing tool parameter" })
      };
    }
    const sanitizedArgs = validateInput(tool, args || {});
    let result;
    switch (tool) {
      case "get_safety_reviews": {
        const { city, country } = sanitizedArgs;
        const { data, error } = await supabase.from("reviews").select(`
            id,
            destination_city,
            destination_country,
            overall_rating,
            night_safety_rating,
            public_transit_rating,
            walking_alone_rating,
            harassment_level,
            review_text,
            tags,
            visited_date,
            helpful_count,
            created_at,
            profiles:user_id (
              full_name,
              avatar_url
            )
          `).eq("destination_city", city).eq("destination_country", country).order("created_at", { ascending: false }).limit(50);
        if (error) throw error;
        result = {
          reviews: data || [],
          count: data?.length || 0,
          destination: `${city}, ${country}`
        };
        break;
      }
      case "get_user_profile": {
        const { user_id } = sanitizedArgs;
        const isOwnProfile = user.id === user_id;
        const selectFields = isOwnProfile ? "*" : "id, full_name, avatar_url, bio, created_at";
        const { data, error } = await supabase.from("profiles").select(selectFields).eq("id", user_id).single();
        if (error) {
          if (error.code === "PGRST116") {
            return {
              statusCode: 404,
              headers,
              body: JSON.stringify({ error: "Profile not found" })
            };
          }
          throw error;
        }
        result = data;
        break;
      }
      case "get_destination_stats": {
        const { city, country } = sanitizedArgs;
        const { data, error } = await supabase.from("reviews").select("overall_rating, night_safety_rating, public_transit_rating, walking_alone_rating, harassment_level").eq("destination_city", city).eq("destination_country", country);
        if (error) throw error;
        result = {
          total_reviews: data.length,
          average_overall: data.length > 0 ? Math.round(data.reduce((sum, r) => sum + r.overall_rating, 0) / data.length * 10) / 10 : 0,
          average_night_safety: data.length > 0 ? Math.round(data.reduce((sum, r) => sum + r.night_safety_rating, 0) / data.length * 10) / 10 : 0,
          average_public_transit: data.length > 0 ? Math.round(data.reduce((sum, r) => sum + r.public_transit_rating, 0) / data.length * 10) / 10 : 0,
          average_walking_alone: data.length > 0 ? Math.round(data.reduce((sum, r) => sum + r.walking_alone_rating, 0) / data.length * 10) / 10 : 0,
          harassment_distribution: data.reduce((acc, r) => {
            acc[r.harassment_level] = (acc[r.harassment_level] || 0) + 1;
            return acc;
          }, {})
        };
        break;
      }
      case "search_destinations": {
        const { query } = sanitizedArgs;
        const { data, error } = await supabase.from("reviews").select("destination_city, destination_country").or(`destination_city.ilike.%${query}%,destination_country.ilike.%${query}%`).limit(10);
        if (error) throw error;
        const uniqueDestinations = [...new Set(data.map((r) => `${r.destination_city}, ${r.destination_country}`))];
        result = uniqueDestinations;
        break;
      }
      case "get_recent_reviews": {
        const { limit = 10 } = sanitizedArgs;
        const safeLimit = Math.min(Math.max(limit, 1), 50);
        const { data, error } = await supabase.from("reviews").select(`
            id,
            destination_city,
            destination_country,
            overall_rating,
            review_text,
            created_at,
            profiles:user_id (
              full_name,
              avatar_url
            )
          `).order("created_at", { ascending: false }).limit(safeLimit);
        if (error) throw error;
        result = data || [];
        break;
      }
      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: `Unsupported tool: ${tool}` })
        };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        content: [
          {
            type: "text",
            text: JSON.stringify(result, null, 2)
          }
        ]
      })
    };
  } catch (error) {
    console.error("MCP function error:", {
      message: error.message,
      ip: clientIP,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    const isAuthError = error.message.includes("authorization") || error.message.includes("token") || error.message.includes("confirmed");
    const statusCode = isAuthError ? 401 : 500;
    const errorMessage = isAuthError ? error.message : "Internal server error";
    return {
      statusCode,
      headers,
      body: JSON.stringify({
        error: errorMessage,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
