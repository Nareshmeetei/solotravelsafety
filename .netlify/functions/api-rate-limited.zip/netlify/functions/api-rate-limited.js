var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_rate_limited_exports = {};
__export(api_rate_limited_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_rate_limited_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing Supabase environment variables");
}
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseAnonKey);
const rateLimitStore = /* @__PURE__ */ new Map();
const checkRateLimit = (ip, endpoint, maxRequests, windowMs) => {
  const now = Date.now();
  const key = `${ip}:${endpoint}`;
  const requests = rateLimitStore.get(key) || [];
  const validRequests = requests.filter((timestamp) => now - timestamp < windowMs);
  if (validRequests.length >= maxRequests) {
    return false;
  }
  validRequests.push(now);
  rateLimitStore.set(key, validRequests);
  return true;
};
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  const clientIP = event.headers["client-ip"] || event.headers["x-forwarded-for"] || event.requestContext?.identity?.sourceIp || "unknown";
  const rateLimitConfig = {
    reviews: { maxRequests: 10, windowMs: 60 * 60 * 1e3 },
    // 10 requests per hour
    newsletter: { maxRequests: 3, windowMs: 60 * 60 * 1e3 },
    // 3 requests per hour
    general: { maxRequests: 100, windowMs: 15 * 60 * 1e3 }
    // 100 requests per 15 minutes
  };
  try {
    const { action, ...data } = JSON.parse(event.body || "{}");
    const config = rateLimitConfig[action] || rateLimitConfig.general;
    const isAllowed = checkRateLimit(clientIP, action, config.maxRequests, config.windowMs);
    if (!isAllowed) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({
          error: "Too many requests",
          message: `Rate limit exceeded. Please try again in ${Math.ceil(config.windowMs / 6e4)} minutes.`,
          retryAfter: Math.ceil(config.windowMs / 1e3)
        })
      };
    }
    let result;
    switch (action) {
      case "addNewsletterSignup":
        result = await supabase.rpc("add_newsletter_signup", {
          p_email: data.email,
          p_source: data.source || "api",
          p_ip_address: clientIP,
          p_user_agent: event.headers["user-agent"] || "unknown"
        });
        break;
      case "getNewsletterStats":
        result = await supabase.rpc("get_newsletter_stats");
        break;
      case "getRecentReviews":
        result = await supabase.from("reviews").select(`
            *,
            profiles:user_id (
              full_name,
              avatar_url
            )
          `).order("created_at", { ascending: false }).limit(data.limit || 10);
        break;
      case "searchReviews":
        result = await supabase.from("reviews").select(`
            *,
            profiles:user_id (
              full_name,
              avatar_url
            )
          `).or(`destination_city.ilike.%${data.query}%,destination_country.ilike.%${data.query}%`).order("created_at", { ascending: false }).limit(20);
        break;
      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Invalid action" })
        };
    }
    if (result.error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: result.error.message })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        data: result.data,
        message: "Action completed successfully"
      })
    };
  } catch (error) {
    console.error("API function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        message: "An unexpected error occurred"
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
